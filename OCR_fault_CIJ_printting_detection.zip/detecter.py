from computorVision_approach.Text_detection import *
import cv2
import time
tool = FirstProgress()
img = cv2.imread('img2.jpg')
while True:
    start = time.time()
    Region, Region_Blur = tool.get_Can_Region(img)
    text_regions = tool.GetTextRegion(Region, Region_Blur)
    text = tool.TextExtracting(text_regions)
    print('FPS: ',1/(time.time()-start+ 10**-6))